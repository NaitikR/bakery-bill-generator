import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.ListSelectionModel;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;



 public class Bakery extends JFrame {

    private static final String CUSTOMER_NAME = "Customer Name:";
    private JLabel name = new JLabel(CUSTOMER_NAME);
    private JLabel email = new JLabel("Email Address:");
    private JLabel telNo = new JLabel("Telephone No:");
    private JLabel Cake = new JLabel("Cake Type:");
    private JLabel cakeFlavour = new JLabel("Cake Flavour:");
    private JLabel size = new JLabel("Size:");
    private JLabel info = new JLabel("Cake info:");
    private JTextField tName = new JTextField();
    private JTextField tEmail = new JTextField();
    private JTextField tTelNo = new JTextField();
    private String[] CakeShape = {"Square", "Circular", "Heart shape", "Rectangle"};
    private JList lCake = new JList(CakeShape);
    private JScrollPane scrollCake = new JScrollPane(lCake);
    private String[] CakeFlav = {"Chocolate", "Fruits", "Hazelnut", "Pineapple", "Butterscotch"};
    private String[] cakeSize = {"Small", "Half kg", "1 kg", "2 kg"};
    private JComboBox cShape= new JComboBox(CakeShape);
    private JComboBox cFlav = new JComboBox(CakeFlav);
    private JComboBox cSize = new JComboBox(cakeSize);
    private JRadioButton delivery = new JRadioButton("Delivery", false);
    private JRadioButton pickUp = new JRadioButton("Pick up", false);
    private JButton submit = new JButton("Submit");
    private JButton clear = new JButton("Clear");
    private JTextArea aInfo = new JTextArea(1, 2);
    private JPanel p1 = new JPanel();
    private JPanel p2 = new JPanel();
    private double amount;
    String selected = "";


    public Bakery()
    {
        lCake.setVisibleRowCount(4);
        lCake.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        Container pane = getContentPane();
        pane.setLayout(new GridLayout(2, 1, 5, 5));
        p1.setLayout(new GridLayout(4, 4));
        p1.add(name);
        p1.add(tName);
        p1.add(email);
        p1.add(tEmail);
        p1.add(telNo);
        p1.add(tTelNo);
        p1.add(Cake);
        p1.add(scrollCake);
        p1.add(cakeFlavour);
        p1.add(cFlav);
        p1.add(size);
        p1.add(cSize);
        p1.add(delivery);
        p1.add(pickUp);
        p1.add(submit);
        p1.add(clear);
        p2.setLayout(new BorderLayout());
        p2.add(info, "West");
        p2.add(aInfo, "Center");
        pane.add(p1);
        pane.add(p2);
        action listener = new action();
        delivery.addActionListener(listener);
        pickUp.addActionListener(listener);
        submit.addActionListener(listener);
        clear.addActionListener(listener);
        item listener1 = new item();
        lCake.addListSelectionListener(listener1);
    }
        class action implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
                Object choice = e.getSource();
                
                if (choice == submit)
                {
                    String item1 = tName.getText();
                    String item2 = tEmail.getText();
                    String item3 = tTelNo.getText();
                    int item6= cShape.getSelectedIndex();
                    int item4 = cFlav.getSelectedIndex();
                    int item5 = cSize.getSelectedIndex();
                    if (delivery.isSelected())
                    {
                        if (cSize.getSelectedItem().equals("Small"))
                        {
                            amount = 200+50; // 50 rupees for delivery
                        }
                        else if (cSize.getSelectedItem().equals("Half kg"))
                        {
                            amount = 300+50;
                        }
                        else if (cSize.getSelectedItem().equals("1 kg"))
                        {
                            amount = 500+50;
                        }
                        else if (cSize.getSelectedItem().equals("2 kg"))
                        {
                            amount = 900+50;
                        }
                    }
                    else if (pickUp.isSelected()) 
                    {
                        if (cSize.getSelectedItem().equals("Small"))
                        {
                            amount = 200;
                        }
                        else if (cSize.getSelectedItem().equals("Half kg"))
                        {
                            amount = 300;
                        }
                        else if (cSize.getSelectedItem().equals("1 kg"))
                        {
                            amount = 500;
                        }
                        else if (cSize.getSelectedItem().equals("2 kg"))
                        {
                            amount = 900;
                        }
                    }
                    aInfo.setText("------INVOICE------- \n"+item1 + "\n" + item2 + "\n" + item3 + "\n" + selected + "\n" + CakeFlav[item4] + "\n" + cakeSize[item5] + "\nTotal price: Rs." + String.format("%.2f", amount));
                    
                
                
                
				Connection con = null;
				try {
					Class.forName("com.mysql.jdbc.Driver");
				} catch (ClassNotFoundException e1) {

					e1.printStackTrace();
				}
				try {
					con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bakerydata", "root", "Naitik_1805");
				} catch (SQLException e1) {
                                    System.out.println(e1);
				}

				
				try {
					String sql = "insert into bill(name,email,mobile,shape,flav,size,amount)" + "values(?,?,?,?,?,?,?)";
					PreparedStatement pr = con.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
					
                                       pr.setString(1,item1);
                                       pr.setString(2,item2);
                                       pr.setString(3,item3);
                                       pr.setString(4,CakeShape[item6]);
                                        pr.setString(5,CakeFlav[item4]);
                                        pr.setString(6,cakeSize[item5]);
                                        pr.setInt(7,(int) amount);
					
					int row_inserted=pr.executeUpdate();
					System.out.println(row_inserted);
				} catch (SQLException e1) {
                                    System.out.println(e1);
				}
                }
            

                
                
                else if (choice == clear)
                {
                    aInfo.setText("");
                   
                }
            }
        }
        class item implements ListSelectionListener
        {
            public void valueChanged(ListSelectionEvent e)
            {
                String str = "";
                int selectedIndex[] = lCake.getSelectedIndices();
                for (int i=0; i<selectedIndex.length; i++)
                {
                    int index = selectedIndex[i];
                    str += CakeShape[index];
                }
                selected = str;
            }
         }
       
   
    public static void main(String[] args) {
     Bakery frame = new Bakery();
     
   frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   frame.setTitle("Order your Cake from us. 30 minutes delivery!");
   frame.setSize(650, 650);
   frame.setVisible(true);  
    }
    
}
